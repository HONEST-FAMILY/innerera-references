import sys
import wave

import numpy as np

SR = 48000
DUR = 20.0
N = int(SR * DUR)
rng = np.random.default_rng(7)


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(dur):
    return np.arange(int(dur * SR)) / SR


def place(buf, sig, t0, gain=1.0, pan=0.0):
    i0 = int(round(t0 * SR))
    if i0 >= N or len(sig) == 0:
        return
    if i0 < 0:
        sig = sig[-i0:]
        i0 = 0
    n = min(len(sig), N - i0)
    l = np.cos((pan + 1) * np.pi / 4) * 1.4142
    r = np.sin((pan + 1) * np.pi / 4) * 1.4142
    buf[0, i0:i0 + n] += sig[:n] * gain * l
    buf[1, i0:i0 + n] += sig[:n] * gain * r


def band(x, lo=None, hi=None, slope=0.15):
    n = len(x)
    size = 1 << int(np.ceil(np.log2(max(n, 2))))
    X = np.fft.rfft(x, size)
    f = np.fft.rfftfreq(size, 1 / SR)
    g = np.ones_like(f)
    if lo:
        g *= 1 / (1 + (lo / np.maximum(f, 1)) ** 4)
    if hi:
        g *= 1 / (1 + (f / hi) ** 4)
    return np.fft.irfft(X * g, size)[:n]


def noise(dur):
    return rng.standard_normal(int(dur * SR))


def adsr(n, a=0.005, d=0.1, s=0.0, r=0.05, hold=None):
    t = np.arange(n) / SR
    e = np.where(t < a, t / a, s + (1 - s) * np.exp(-(t - a) / max(d, 1e-4)))
    if hold is not None:
        e = e * np.clip(1 - (t - hold) / r, 0, 1)
    return e


def kick():
    t = tt(0.55)
    f = 46 + 84 * np.exp(-t / 0.032)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t / 0.26) * np.clip(t / 0.002, 0, 1)
    click = band(noise(0.55), lo=1500, hi=9000) * np.exp(-t / 0.004) * 0.35
    x = np.tanh(1.6 * (body + click)) / np.tanh(1.6)
    return x


def clap():
    t = tt(0.45)
    nz = band(noise(0.45), lo=900, hi=6000)
    e = np.zeros_like(t)
    for k, d in enumerate([0.0, 0.011, 0.022]):
        e += np.where(t >= d, np.exp(-(t - d) / 0.006), 0) * (0.8 if k < 2 else 1.0)
    e += np.where(t >= 0.026, np.exp(-(t - 0.026) / 0.13), 0) * 0.55
    return nz * e * 0.6


def hat(open_=False):
    d = 0.32 if open_ else 0.11
    t = tt(d)
    return band(noise(d), lo=7200, hi=16000) * np.exp(-t / (0.16 if open_ else 0.032)) * 0.55


def shaker():
    t = tt(0.09)
    return band(noise(0.09), lo=4200, hi=11000) * np.clip(t / 0.012, 0, 1) * np.exp(-t / 0.035) * 0.35


def bass(m, dur):
    t = tt(dur + 0.08)
    f = midi(m)
    x = np.sin(2 * np.pi * f * t) + 0.42 * np.sin(4 * np.pi * f * t) + 0.16 * np.sin(6 * np.pi * f * t)
    e = adsr(len(t), a=0.006, d=0.16, s=0.62, r=0.07, hold=dur)
    return np.tanh(1.3 * x * e) * 0.8


def ep_note(m, dur, vel=1.0):
    t = tt(dur + 0.6)
    f = midi(m)
    x = np.zeros_like(t)
    for k, (amp, tau) in enumerate([(1.0, 1.4), (0.28, 0.6), (0.11, 0.35), (0.05, 0.2)], start=1):
        x += amp * np.sin(2 * np.pi * f * k * t + 0.3 * k) * np.exp(-t / tau)
    x += 0.09 * np.sin(2 * np.pi * f * 7.02 * t) * np.exp(-t / 0.018)
    e = np.clip(t / 0.004, 0, 1) * np.clip(1 - (t - dur) / 0.35, 0, 1)
    return x * e * vel


def chord(notes, t0, dur, gain, buf, wet):
    for i, m in enumerate(notes):
        sig = ep_note(m, dur, 1.0 - 0.06 * i)
        trem = 1 + 0.10 * np.sin(2 * np.pi * 4.6 * tt(len(sig) / SR) + i)
        pan = -0.35 + 0.7 * i / max(len(notes) - 1, 1)
        place(buf, sig * trem, t0 + 0.004 * i, gain, pan)
        place(wet, sig, t0 + 0.004 * i, gain * 0.5, pan)


def pad(notes, t0, dur, gain, buf, att=0.35, rel=0.8):
    t = tt(dur + rel)
    x = np.zeros_like(t)
    for m in notes:
        for det in (-0.07, 0.0, 0.07):
            f = midi(m) * 2 ** (det / 12)
            ph = rng.uniform(0, 1)
            saw = 2 * ((f * t + ph) % 1.0) - 1
            x += saw
    x = band(x, lo=120, hi=1900) / (len(notes) * 3)
    e = np.clip(t / att, 0, 1) * np.clip(1 - (t - dur) / rel, 0, 1)
    place(buf, x * e, t0, gain, -0.2)
    place(buf, np.roll(x, 900) * e, t0, gain, 0.2)


def bell(m, dur=1.1):
    t = tt(dur)
    f = midi(m)
    idx = 2.2 * np.exp(-t / 0.12)
    x = np.sin(2 * np.pi * f * t + idx * np.sin(2 * np.pi * f * 3.5 * t))
    x += 0.25 * np.sin(2 * np.pi * f * 2 * t) * np.exp(-t / 0.25)
    return x * np.exp(-t / 0.42) * np.clip(t / 0.002, 0, 1) * 0.55


def pluck(m, dur=0.35):
    t = tt(dur)
    f = midi(m)
    x = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)
    return x * np.exp(-t / 0.09) * np.clip(t / 0.002, 0, 1) * 0.4


def pop(f0, f1, tau=0.05, dur=0.18):
    t = tt(dur)
    f = f1 + (f0 - f1) * np.exp(-t / 0.018)
    ph = 2 * np.pi * np.cumsum(f) / SR
    click = band(noise(dur), lo=2000, hi=9000) * np.exp(-t / 0.002) * 0.25
    return (np.sin(ph) * np.exp(-t / tau) + click) * np.clip(t / 0.001, 0, 1)


def whoosh(dur, rise=True, lo=300, hi=7000):
    t = tt(dur)
    nz = noise(dur)
    a = band(nz, lo=lo, hi=lo * 4)
    b = band(nz, lo=hi / 4, hi=hi)
    u = t / dur
    m = u if rise else 1 - u
    env = np.sin(np.pi * np.clip(u, 0, 1)) ** 1.5 if not rise else np.clip(u, 0, 1) ** 1.8 * np.clip((1 - u) / 0.08, 0, 1)
    if not rise:
        env = np.clip(u / 0.05, 0, 1) * (1 - u) ** 1.6
    return (a * (1 - m) + b * m) * env * 0.5


def sweep_down(dur, f0, f1):
    t = tt(dur)
    f = f1 + (f0 - f1) * np.exp(-t / (dur / 3))
    ph = 2 * np.pi * np.cumsum(f) / SR
    nz = band(noise(dur), lo=600, hi=5000)
    e = np.clip(t / 0.01, 0, 1) * (1 - t / dur) ** 1.2
    return (0.5 * np.sin(ph) + 0.35 * nz) * e


def tok():
    t = tt(0.25)
    x = 0.9 * np.sin(2 * np.pi * 1650 * t) * np.exp(-t / 0.022)
    x += 0.45 * np.sin(2 * np.pi * 2930 * t) * np.exp(-t / 0.012)
    x += 0.35 * np.sin(2 * np.pi * 820 * t) * np.exp(-t / 0.04)
    x += band(noise(0.25), lo=3000, hi=14000) * np.exp(-t / 0.003) * 0.6
    return x * np.clip(t / 0.0006, 0, 1)


def boom():
    t = tt(1.0)
    f = 48 + 70 * np.exp(-t / 0.05)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.tanh(1.4 * np.sin(ph) * np.exp(-t / 0.42) * np.clip(t / 0.003, 0, 1))


def tick(f, dur=0.05):
    t = tt(dur)
    return (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.012) + band(noise(dur), lo=2500, hi=9000) * np.exp(-t / 0.004) * 0.4)


def swipe(dur=0.12):
    t = tt(dur)
    return band(noise(dur), lo=1800, hi=7000) * np.sin(np.pi * t / dur) ** 2 * 0.5


def reverb(x, seconds=2.2, seed=5):
    r = np.random.default_rng(seed)
    n = int(seconds * SR)
    t = np.arange(n) / SR
    out = np.zeros_like(x)
    for ch in range(2):
        ir = r.standard_normal(n) * np.exp(-t / (seconds / 6.5))
        ir = band(ir, lo=200, hi=6500)
        ir[: int(0.012 * SR)] *= np.linspace(0, 1, int(0.012 * SR))
        ir /= np.sqrt(np.sum(ir ** 2))
        size = 1 << int(np.ceil(np.log2(len(x[ch]) + n)))
        y = np.fft.irfft(np.fft.rfft(x[ch], size) * np.fft.rfft(ir, size), size)[: len(x[ch])]
        out[ch] = y
    return out


FMAJ9 = [53, 57, 60, 64, 67]
DM9 = [50, 53, 57, 60, 64]
BBMAJ9 = [46, 50, 53, 57, 60]
C11 = [48, 53, 58, 62, 67]
PROG = [FMAJ9, DM9, BBMAJ9, C11]
ROOT = [41, 38, 34, 36]


def main(out_path):
    dry = np.zeros((2, N))
    wet = np.zeros((2, N))
    drums = np.zeros((2, N))

    pad(FMAJ9, 0.0, 1.45, 0.20, dry, att=0.25, rel=0.4)
    for i, m in enumerate([65, 69, 72, 76, 72, 69]):
        place(dry, pluck(m + 12), 0.0 + 0.25 * i, 0.22, -0.3 + 0.12 * i)
        place(wet, pluck(m + 12), 0.0 + 0.25 * i, 0.18)
    place(dry, sweep_down(0.36, 1500, 220), 0.25, 0.28)
    place(dry, pop(980, 430), 0.75, 0.42)
    place(dry, whoosh(0.42, rise=True), 1.08, 0.55)

    def drum_section(a, b):
        k = 0
        t = a
        while t < b - 1e-6:
            place(drums, kick(), t, 0.95)
            if k % 2 == 1:
                place(drums, clap(), t, 0.5, 0.05)
                place(wet, clap(), t, 0.25)
            place(drums, hat(open_=(k % 4 == 3)), t + 0.25, 0.32 if k % 4 == 3 else 0.42, 0.25)
            for s in range(4):
                place(drums, shaker(), t + 0.125 * s + (0.012 if s % 2 else 0), 0.16, -0.3)
            k += 1
            t += 0.5

    drum_section(1.5, 12.5)
    drum_section(13.5, 17.5)

    bars = [1.5 + 2 * i for i in range(8)]
    for bi, b0 in enumerate(bars):
        ch = PROG[bi % 4]
        if b0 < 12.5 or b0 >= 13.5:
            chord(ch, b0, 1.2, 0.17, dry, wet)
            chord(ch, b0 + 1.25, 0.5, 0.11, dry, wet)
        root = ROOT[bi % 4]
        for k in range(4):
            tb = b0 + 0.5 * k + 0.25
            if 12.5 <= tb < 13.5 or tb >= 17.5:
                continue
            place(dry, bass(root if k != 2 else root + 12, 0.2), tb, 0.36)
    place(dry, bass(41, 0.45), 1.5, 0.30)

    pad(DM9, 12.5, 1.0, 0.16, dry, att=0.08, rel=0.5)
    pad(FMAJ9, 17.5, 1.6, 0.22, dry, att=0.05, rel=0.9)
    chord(FMAJ9 + [72], 17.5, 1.6, 0.2, dry, wet)
    place(drums, kick(), 17.5, 0.9)
    place(dry, bass(41, 0.9), 17.5, 0.34)

    for i, m in enumerate([77, 79, 81, 84, 86]):
        place(dry, bell(m), 4.0 + 0.5 * i, 0.30, -0.2 + 0.1 * i)
        place(wet, bell(m), 4.0 + 0.5 * i, 0.30)
    for i in range(4):
        place(dry, tick(1500 + 180 * i, 0.04), 6.5 + 0.05 * i, 0.16, -0.4 + 0.25 * i)
    place(dry, whoosh(0.32, rise=False, lo=250, hi=5000), 3.84, 0.42)
    place(dry, whoosh(0.4, rise=True), 7.42, 0.5)
    for i in range(5):
        place(dry, swipe(0.16), 8.0 + 0.25 * i, 0.22, -0.2 + 0.1 * i)
    place(dry, whoosh(0.72, rise=False, lo=200, hi=4000), 9.25, 0.35)
    place(dry, whoosh(0.3, rise=True, lo=500, hi=8000), 9.98, 0.4)
    place(dry, whoosh(0.3, rise=False, lo=400, hi=6000), 12.0, 0.25)
    place(dry, tok(), 12.5, 0.85)
    place(wet, tok(), 12.5, 0.55)
    place(dry, whoosh(0.34, rise=False, lo=150, hi=3000), 12.5, 0.45)
    place(drums, boom(), 12.85, 0.75)
    place(dry, pop(620, 210, tau=0.09, dur=0.3), 13.25, 0.42)
    place(wet, pop(620, 210, tau=0.09, dur=0.3), 13.25, 0.25)
    place(dry, whoosh(0.36, rise=True, lo=300, hi=7000), 14.45, 0.45)
    for k in range(14):
        place(dry, tick(1300 + 70 * k, 0.04), 14.92 + 0.05 * k, 0.13, -0.6 + 1.2 * k / 13)
    place(dry, whoosh(0.32, rise=True, lo=250, hi=6000), 16.46, 0.5)
    place(dry, pop(880, 520), 16.76, 0.32)
    place(dry, pop(760, 380), 17.75, 0.36)
    place(wet, bell(84, 1.6), 17.5, 0.2)
    place(dry, bell(84, 1.6), 17.5, 0.14)

    mix = dry + 0.85 * drums + 0.32 * reverb(wet)
    mix = np.stack([band(mix[0], lo=28), band(mix[1], lo=28)])
    t = np.arange(N) / SR
    fade = np.clip(1 - (t - 18.9) / 1.05, 0, 1) ** 1.5
    mix *= fade
    mix = np.tanh(mix * 0.9) / 0.9
    peak = np.max(np.abs(mix))
    mix = mix / peak * 0.89
    pcm = (np.clip(mix.T, -1, 1) * 32767).astype(np.int16)
    with wave.open(out_path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("wrote", out_path, N / SR)


if __name__ == "__main__":
    main(sys.argv[1])
