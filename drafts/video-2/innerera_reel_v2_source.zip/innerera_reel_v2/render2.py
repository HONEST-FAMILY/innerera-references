import argparse
import base64
import os
import subprocess
import sys
import time
from io import BytesIO

from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

FF = r"C:\Users\hiwgyum\issue1918\bin\ffmpeg-9.0.2-essentials_build\bin\ffmpeg.exe"
URL = "http://127.0.0.1:8919/index.html?render=1"
GPU = ["--use-angle=d3d11", "--enable-gpu-rasterization", "--ignore-gpu-blocklist", "--force-color-profile=srgb", "--hide-scrollbars"]
FPS = 60
CHROME = "C:/Users/hiwgyum/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe"


def open_page(p, gpu=True):
    browser = p.chromium.launch(headless=True, executable_path=CHROME, args=GPU if gpu else ["--force-color-profile=srgb", "--hide-scrollbars"])
    page = browser.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
    page.goto(URL, wait_until="load")
    page.wait_for_function("window.__ready === true", timeout=90000)
    cdp = page.context.new_cdp_session(page)
    return browser, page, cdp


def grab(page, cdp, t):
    page.evaluate("t => window.seek(t)", t)
    r = cdp.send("Page.captureScreenshot", {"format": "png", "optimizeForSpeed": True})
    return base64.b64decode(r["data"])


def stills(times, out, cols, cell):
    with sync_playwright() as p:
        browser, page, cdp = open_page(p)
        ims = [(t, Image.open(BytesIO(grab(page, cdp, t))).convert("RGB")) for t in times]
        browser.close()
    ch = int(cell * 1920 / 1080)
    rows = (len(ims) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * (ch + 18)), (255, 255, 255))
    d = ImageDraw.Draw(sheet)
    for i, (t, im) in enumerate(ims):
        x, y = (i % cols) * cell, (i // cols) * (ch + 18)
        sheet.paste(im.resize((cell - 4, ch), Image.LANCZOS), (x, y + 16))
        d.text((x + 2, y + 2), f"{t:.2f}s", fill=(200, 0, 0))
    sheet.save(out, quality=88)
    print("sheet", out, len(ims))


def single(t, out):
    with sync_playwright() as p:
        browser, page, cdp = open_page(p)
        Image.open(BytesIO(grab(page, cdp, t))).convert("RGB").save(out, quality=94)
        browser.close()
    print("saved", out)


def worker(f0, f1, sub, out):
    shutter = 0.5
    vf = (f"tmix=frames={sub}:weights='{' '.join(['1'] * sub)}',select='eq(mod(n\\,{sub})\\,{sub - 1})',setpts=N/({FPS}*TB),"
          "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p")
    cmd = [FF, "-y", "-loglevel", "error", "-f", "image2pipe", "-framerate", str(FPS * sub), "-c:v", "png", "-i", "-",
           "-vf", vf, "-r", str(FPS), "-c:v", "libx264", "-preset", "medium", "-crf", "13", "-profile:v", "high",
           "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv", out]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t0 = time.time()
    with sync_playwright() as p:
        browser, page, cdp = open_page(p)
        for f in range(f0, f1):
            for s in range(sub):
                t = f / FPS + (s + 0.5) / sub * shutter / FPS
                proc.stdin.write(grab(page, cdp, t))
            if (f - f0) % 60 == 0:
                print(f"[{f0}-{f1}] frame {f} {time.time() - t0:.1f}s", flush=True)
        browser.close()
    proc.stdin.close()
    proc.wait()
    print(f"[{f0}-{f1}] done {time.time() - t0:.1f}s", flush=True)


def video(out, dur, sub, jobs, tmpdir):
    n = int(round(dur * FPS))
    os.makedirs(tmpdir, exist_ok=True)
    edges = [round(i * n / jobs) for i in range(jobs + 1)]
    parts, procs = [], []
    for j in range(jobs):
        part = os.path.join(tmpdir, f"part{j:02d}.mp4")
        parts.append(part)
        procs.append(subprocess.Popen([sys.executable, "-I", __file__, "worker", "--f0", str(edges[j]), "--f1", str(edges[j + 1]),
                                       "--sub", str(sub), "--out", part], stdout=open(part + ".log", "w"), stderr=subprocess.STDOUT))
        time.sleep(2.0)
    for pr in procs:
        pr.wait()
    lst = os.path.join(tmpdir, "parts.txt")
    with open(lst, "w") as fh:
        for part in parts:
            fh.write(f"file '{os.path.abspath(part)}'\n")
    subprocess.run([FF, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", out], check=True)
    print("video", out, n)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["stills", "single", "video", "worker"])
    ap.add_argument("--times", default="")
    ap.add_argument("--out", required=True)
    ap.add_argument("--cols", type=int, default=6)
    ap.add_argument("--cell", type=int, default=270)
    ap.add_argument("--dur", type=float, default=20.0)
    ap.add_argument("--sub", type=int, default=4)
    ap.add_argument("--jobs", type=int, default=6)
    ap.add_argument("--f0", type=int, default=0)
    ap.add_argument("--f1", type=int, default=0)
    ap.add_argument("--tmp", default=r"C:\Users\hiwgyum\issue1918\v2out\parts")
    a = ap.parse_args()
    if a.mode == "stills":
        stills([float(x) for x in a.times.split(",")], a.out, a.cols, a.cell)
    elif a.mode == "single":
        single(float(a.times), a.out)
    elif a.mode == "worker":
        worker(a.f0, a.f1, a.sub, a.out)
    else:
        video(a.out, a.dur, a.sub, a.jobs, a.tmp)
