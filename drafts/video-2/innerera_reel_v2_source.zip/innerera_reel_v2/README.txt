이너에라 롱지비티 릴스 영상 시안 2 — 편집 원본

[들어 있는 것]
- index.html : 영상 원본. 시간 t를 받아 한 장면을 그리는 한 장짜리 HTML(window.seek(t)).
               브라우저에서 열면 반복 재생, index.html?t=12.5 로 그 시각 한 장면만 볼 수 있습니다.
- img/       : 상자 앞면(최종 단상자 인쇄 원본), 스틱, 젤리 사진, 원료 사진(Unsplash 무료 사진), 로고
- fonts/     : Pretendard(SIL OFL), Jost(SIL OFL)와 라이선스 글
- SPEC.md    : 박자 지도(몇 초에 무엇이 나오는지), 색·글꼴, 문구 근거
- render2.py : 영상 굽기(크롬 화면을 1초 60장 x 서브프레임 8장으로 찍어 ffmpeg로 합침)
- music2.py  : 배경음 합성(120BPM, 직접 만든 소리라 저작권 문제 없음)

[S-Core Dream 글꼴은 따로 받기]
제목 글꼴 S-Core Dream은 파일을 넣지 않았습니다. 아래 주소에서 받아 fonts/ 에 같은 이름으로 넣으세요.
https://fastly.jsdelivr.net/gh/projectnoonnu/noonfonts_six@1.2/S-CoreDream-3Light.woff
https://fastly.jsdelivr.net/gh/projectnoonnu/noonfonts_six@1.2/S-CoreDream-4Regular.woff
https://fastly.jsdelivr.net/gh/projectnoonnu/noonfonts_six@1.2/S-CoreDream-6Bold.woff
https://fastly.jsdelivr.net/gh/projectnoonnu/noonfonts_six@1.2/S-CoreDream-7ExtraBold.woff
https://fastly.jsdelivr.net/gh/projectnoonnu/noonfonts_six@1.2/S-CoreDream-8Heavy.woff
https://fastly.jsdelivr.net/gh/projectnoonnu/noonfonts_six@1.2/S-CoreDream-9Black.woff

[다시 굽는 법]
1) 이 폴더에서  python -m http.server 8919
2) python render2.py video --out reel_noaudio.mp4 --dur 20 --sub 8 --jobs 6
   (render2.py 위쪽 FF·CHROME 경로를 내 PC의 ffmpeg·크롬 경로로 바꿉니다)
3) python music2.py music_raw.wav  → ffmpeg loudnorm 으로 -14 LUFS 맞춤
4) ffmpeg -i reel_noaudio.mp4 -i music.wav -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart 완성.mp4

[사진 출처]
- 양파·효모·강황·시금치·플라스크: Unsplash 무료 사진(Unsplash License). 작가·원본 주소는 innerera-references 저장소 assets/photos/d/CREDITS.txt, assets/photos/five/CREDITS.txt
- 상자 앞면·스틱·젤리 사진: 이너에라 제공 자료
